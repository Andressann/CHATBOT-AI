package uao.IACoomeva.IAbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(IaBackendApplication.class, args);
	}

}
